#include <string.h>
#include <stdio.h>

int main(){
    char palavra[20] = "LeagueOfLegends";
    int tamanho = strlen(palavra);
    
    printf("Tamanho = %d",tamanho);

    return 0;
}
