#include <stdio.h>
#include <stdlib.h>
#include <string.h>


int main(){
    
    struct ibge{
        float sal;
        int idad, fi;
        char sex;
    };
    
    struct ibge p[2];
    float soma_sal=0, soma_fi=0, maior=0;
    int i;
    for(i=0;i<2;i++){
        printf("Escreva seu salario:\n");
        scanf("%f",&p[i].sal);
        soma_sal = soma_sal + p[i].sal;
        if(maior < p[i].sal){
            maior=p[i].sal;
        }
        //printf("Escreva sua idade:\n");
        //scanf("%d",&p[i].idad);
        //printf("Escreva seu sexo: (M/F)\n");
        //getchar();
        //scanf("%c",&p[i].sex);
        printf("Escreva sua quantidade de filhos:\n");
        scanf("%d",&p[i].fi);
        soma_fi = soma_fi + p[i].fi;
        
    }
    float media_s=0, media_fi=0;
    
    media_s = soma_sal/2;
    media_fi = soma_fi/2;
    printf("Media do salario; %d\n",media_s);
    printf("Media de filhos; %d\n",media_fi);


    return 0;
}
